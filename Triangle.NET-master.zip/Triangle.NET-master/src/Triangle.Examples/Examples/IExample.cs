﻿
namespace TriangleNet.Examples
{
    public interface IExample
    {
        bool Run(bool print);
    }
}
